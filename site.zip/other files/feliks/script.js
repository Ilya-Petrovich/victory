$(document).ready(function(){
    $(".owl-carousel").owlCarousel({
        items:1,
        loop:false,
        nav:true,
        dots:false,
        navText:[,"<img src='/images/nextArrow.png'>"],
        autoHeight:true,
        mouseDrag:false,
        touchDrag:false,
        
    });
  });
  
